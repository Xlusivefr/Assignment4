/*
 * Class: CMSC203 
 * Instructor: Dr.Grinberg
 * Description: Contains unit tests to validate the functionality of the Plot class.
 * Due: 10/24/24
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. 
 * I have not copied the code from a student or any source. 
 * I have not given my code to any student.
 * Print your Name here: Jedidiah Dawit
*/

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class PlotTestStudent {
    private Plot plot1;
    private Plot plot2;

    @Before
    public void setUp() {
        plot1 = new Plot(0, 0, 10, 10);
        plot2 = new Plot(5, 5, 5, 5);
    }

    @Test
    public void testDefaultConstructor() {
        Plot defaultPlot = new Plot();
        assertEquals(0, defaultPlot.getX());
        assertEquals(0, defaultPlot.getY());
        assertEquals(1, defaultPlot.getWidth());
        assertEquals(1, defaultPlot.getDepth());
    }

    @Test
    public void testParameterizedConstructor() {
        assertEquals(0, plot1.getX());
        assertEquals(0, plot1.getY());
        assertEquals(10, plot1.getWidth());
        assertEquals(10, plot1.getDepth());
    }

    @Test
    public void testCopyConstructor() {
        Plot copyPlot = new Plot(plot1);
        assertEquals(plot1.getX(), copyPlot.getX());
        assertEquals(plot1.getY(), copyPlot.getY());
        assertEquals(plot1.getWidth(), copyPlot.getWidth());
        assertEquals(plot1.getDepth(), copyPlot.getDepth());
    }

    @Test
    public void testOverlaps() {
        assertTrue(plot1.overlaps(plot2));
        assertFalse(plot2.overlaps(new Plot(20, 20, 5, 5)));
    }

    @Test
    public void testEncompasses() {
        assertTrue(plot1.encompasses(plot2));
        assertFalse(plot2.encompasses(plot1));
    }

    @Test
    public void testSettersAndGetters() {
        plot1.setX(2);
        plot1.setY(3);
        plot1.setWidth(15);
        plot1.setDepth(15);

        assertEquals(2, plot1.getX());
        assertEquals(3, plot1.getY());
        assertEquals(15, plot1.getWidth());
        assertEquals(15, plot1.getDepth());
    }

    @Test
    public void testToString() {
        assertEquals("0,0,10,10", plot1.toString());
    }
}
