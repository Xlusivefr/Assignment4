/*
 * Class: CMSC203 
 * Instructor: Dr.Grinberg
 * Description: Manages a collection of properties, allowing for the addition, removal, and retrieval of properties, along with calculating total rent and management fees.
 * Due: 10/24/24
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. 
 * I have not copied the code from a student or any source. 
 * I have not given my code to any student.
 * Print your Name here: Jedidiah Dawit
*/
public class ManagementCompany {
    public static final int MAX_PROPERTY = 10; // Example maximum capacity
    public static final int MGMT_WIDTH = 100;   // Example width for the plot
    public static final int MGMT_DEPTH = 100;   // Example depth for the plot

    private String name;
    private String taxID;
    private double mgmFee;
    private Property[] properties;
    private int propertyCount;
    private Plot plot;

    public ManagementCompany() {
        this.name = "";
        this.taxID = "";
        this.mgmFee = 0.0;
        this.properties = new Property[MAX_PROPERTY];
        this.propertyCount = 0;
        this.plot = new Plot(0, 0, MGMT_WIDTH, MGMT_DEPTH);
    }

    public ManagementCompany(String name, String taxID, double mgmFee) {
        this.name = name;
        this.taxID = taxID;
        this.mgmFee = mgmFee;
        this.properties = new Property[MAX_PROPERTY];
        this.propertyCount = 0;
        this.plot = new Plot(0, 0, MGMT_WIDTH, MGMT_DEPTH);
    }

    public ManagementCompany(String name, String taxID, double mgmFee, int x, int y, int width, int depth) {
        this.name = name;
        this.taxID = taxID;
        this.mgmFee = mgmFee;
        this.properties = new Property[MAX_PROPERTY];
        this.propertyCount = 0;
        this.plot = new Plot(x, y, width, depth);
    }

    public ManagementCompany(ManagementCompany otherCompany) {
        this.name = otherCompany.name;
        this.taxID = otherCompany.taxID;
        this.mgmFee = otherCompany.mgmFee;
        this.properties = otherCompany.properties.clone();
        this.propertyCount = otherCompany.propertyCount;
        this.plot = new Plot(otherCompany.plot);
    }

    public int addProperty(String name, String city, double rent, String owner) {
        return addProperty(new Property(name, city, rent, owner));
    }

    public int addProperty(String name, String city, double rent, String owner, int x, int y, int width, int depth) {
        return addProperty(new Property(name, city, rent, owner, x, y, width, depth));
    }

    public int addProperty(Property property) {
        if (propertyCount >= MAX_PROPERTY) return -1;
        if (property == null) return -2;

        // Check if property fits within plot and does not overlap existing properties
        // (Implement your own logic for these checks)
        // Assuming plot encompasses property plot check and overlap check is done here

        properties[propertyCount++] = property;
        return propertyCount - 1; // return index where added
    }

    public Property getHighestRentPropperty() {
        if (propertyCount == 0) return null;
        Property highest = properties[0];
        for (int i = 1; i < propertyCount; i++) {
            if (properties[i].getRentAmount() > highest.getRentAmount()) {
                highest = properties[i];
            }
        }
        return highest;
    }

    public double getMgmFeePer() {
        return mgmFee;
    }

    public String getName() {
        return name;
    }

    public Plot getPlot() {
        return plot;
    }

    public Property[] getProperties() {
        return properties;
    }

    public int getPropertiesCount() {
        return propertyCount;
    }

    public String getTaxID() {
        return taxID;
    }

    public double getTotalRent() {
        double total = 0;
        for (int i = 0; i < propertyCount; i++) {
            total += properties[i].getRentAmount();
        }
        return total;
    }

    public boolean isMangementFeeValid() {
        return mgmFee >= 0 && mgmFee <= 100;
    }

    public boolean isPropertiesFull() {
        return propertyCount >= MAX_PROPERTY;
    }

    public void removeLastProperty() {
        if (propertyCount > 0) {
            properties[--propertyCount] = null;
        }
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder("Management Company: " + name + ", Tax ID: " + taxID + "\n");
        for (int i = 0; i < propertyCount; i++) {
            result.append(properties[i].toString()).append("\n");
        }
        return result.toString();
    }
}
