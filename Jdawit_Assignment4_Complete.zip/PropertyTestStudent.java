/*
 * Class: CMSC203 
 * Instructor: Dr.Grinberg
 * Description:Provides unit tests for the Property class, checking property creation, getter methods, and the toString method.
 * Due: 10/24/24
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. 
 * I have not copied the code from a student or any source. 
 * I have not given my code to any student.
 * Print your Name here: Jedidiah Dawit
*/
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class PropertyTestStudent {

    private Property property;

    @BeforeEach
    public void setUp() {
        property = new Property("Test Property", "Test City", 1500.0, "Test Owner");
    }

    @Test
    public void testGetPropertyName() {
        assertEquals("Test Property", property.getPropertyName());
    }

    @Test
    public void testGetCity() {
        assertEquals("Test City", property.getCity());
    }

    @Test
    public void testGetRentAmount() {
        assertEquals(1500.0, property.getRentAmount());
    }

    @Test
    public void testGetOwner() {
        assertEquals("Test Owner", property.getOwner());
    }

    @Test
    public void testGetPlot() {
        Plot plot = property.getPlot();
        assertNotNull(plot);  // Check if plot is created
    }

    @Test
    public void testToString() {
        String expected = "Test Property,Test City,Test Owner,1500.0";
        assertEquals(expected, property.toString());
    }
}
