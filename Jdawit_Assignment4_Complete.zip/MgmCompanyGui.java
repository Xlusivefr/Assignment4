/*
 * Class: CMSC203 
 * Instructor: Dr.Grinberg
 * Description:A JavaFX application that allows users to input property details and visualize added properties as houses on a plot.
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. 
 * I have not copied the code from a student or any source. 
 * I have not given my code to any student.
 * Print your Name here: Jedidiah Dawit
*/

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class MgmCompanyGui extends Application {
    private TextField mgmNameText, mgmIdText, mgmFeeText;
    private TextField propNameText, propCityText, propRentText, propOwnerText;
    private TextField propPlotXText, propPlotYText, propPlotWidthText, propPlotDepthText;

    private Button newMgmBtn, addPropertyBtn, maxRentBtn, totalRentBtn, propListBtn, exitBtn;
    private ManagementCompany mgmCompany;
    private List<Property> properties = new ArrayList<>();
    private Group plotFrame;

    @Override
    public void start(Stage stage) {
        // Main Pane
        VBox mainPane = new VBox(10);
        mainPane.setPadding(new Insets(10));

        // Management Company Input
        GridPane mgmPane = new GridPane();
        mgmPane.setHgap(10);
        mgmPane.setVgap(10);

        mgmNameText = new TextField();
        mgmIdText = new TextField();
        mgmFeeText = new TextField();

        mgmPane.add(new Label("Name:"), 0, 0);
        mgmPane.add(mgmNameText, 1, 0);
        mgmPane.add(new Label("Tax ID:"), 0, 1);
        mgmPane.add(mgmIdText, 1, 1);
        mgmPane.add(new Label("Fee %:"), 0, 2);
        mgmPane.add(mgmFeeText, 1, 2);
        TitledPane mgmTitlePane = new TitledPane("Management Company", mgmPane);
        mgmTitlePane.setCollapsible(false);

        // Property Information Input
        GridPane propertyPane = new GridPane();
        propertyPane.setHgap(10);
        propertyPane.setVgap(10);

        propNameText = new TextField();
        propCityText = new TextField();
        propRentText = new TextField();
        propOwnerText = new TextField();
        propPlotXText = new TextField();
        propPlotYText = new TextField();
        propPlotWidthText = new TextField();
        propPlotDepthText = new TextField();

        propertyPane.add(new Label("Property Name:"), 0, 0);
        propertyPane.add(propNameText, 1, 0);
        propertyPane.add(new Label("City:"), 0, 1);
        propertyPane.add(propCityText, 1, 1);
        propertyPane.add(new Label("Rent:"), 0, 2);
        propertyPane.add(propRentText, 1, 2);
        propertyPane.add(new Label("Owner:"), 0, 3);
        propertyPane.add(propOwnerText, 1, 3);

        propertyPane.add(new Label("Plot X Value:"), 2, 0);
        propertyPane.add(propPlotXText, 3, 0);
        propertyPane.add(new Label("Plot Y Value:"), 2, 1);
        propertyPane.add(propPlotYText, 3, 1);
        propertyPane.add(new Label("Plot Width:"), 2, 2);
        propertyPane.add(propPlotWidthText, 3, 2);
        propertyPane.add(new Label("Plot Depth:"), 2, 3);
        propertyPane.add(propPlotDepthText, 3, 3);

        TitledPane propertyTitlePane = new TitledPane("Property Information", propertyPane);
        propertyTitlePane.setCollapsible(false);

        // Buttons
        HBox buttonPane = new HBox(10);
        newMgmBtn = new Button("New Management Company");
        addPropertyBtn = new Button("Add Property");
        maxRentBtn = new Button("Max Rent");
        totalRentBtn = new Button("Total Rents");
        propListBtn = new Button("List of Properties");
        exitBtn = new Button("Exit");

        buttonPane.getChildren().addAll(newMgmBtn, addPropertyBtn, maxRentBtn, totalRentBtn, propListBtn, exitBtn);
        buttonPane.setAlignment(Pos.CENTER);

        // Plot Frame for properties
        plotFrame = new Group();

        // Add everything to main pane
        mainPane.getChildren().addAll(mgmTitlePane, propertyTitlePane, buttonPane, plotFrame);

        // Set scene
        Scene scene = new Scene(mainPane, 600, 400);
        stage.setScene(scene);
        stage.setTitle("Property Management");
        stage.show();

        // Set button actions
        setButtonActions();
    }

    private void setButtonActions() {
        newMgmBtn.setOnAction(e -> createNewMgm());
        addPropertyBtn.setOnAction(e -> addProp());
        maxRentBtn.setOnAction(e -> displayMaxRent());
        totalRentBtn.setOnAction(e -> displayTotalRent());
        propListBtn.setOnAction(e -> displayPropertyList());
        exitBtn.setOnAction(e -> System.exit(0));
    }

    private void createNewMgm() {
        String name = mgmNameText.getText();
        String taxId = mgmIdText.getText();
        double feePercentage;

        try {
            feePercentage = Double.parseDouble(mgmFeeText.getText());
        } catch (NumberFormatException e) {
            showAlert("Invalid Fee Percentage");
            return;
        }

        mgmCompany = new ManagementCompany(name, taxId, feePercentage);
        properties.clear(); // Clear previous properties
        showAlert("Management Company Created");
    }

    private void addProp() {
        if (mgmCompany == null) {
            showAlert("Please create a management company first.");
            return;
        }

        String propertyName = propNameText.getText();
        String city = propCityText.getText();
        double rent;

        try {
            rent = Double.parseDouble(propRentText.getText());
        } catch (NumberFormatException e) {
            showAlert("Invalid Rent Value");
            return;
        }

        String owner = propOwnerText.getText();
        int x, y, width, depth;

        try {
            x = Integer.parseInt(propPlotXText.getText());
            y = Integer.parseInt(propPlotYText.getText());
            width = Integer.parseInt(propPlotWidthText.getText());
            depth = Integer.parseInt(propPlotDepthText.getText());
        } catch (NumberFormatException e) {
            showAlert("Invalid Plot Values");
            return;
        }

        Property property = new Property(propertyName, city, rent, owner, x, y, width, depth);
        mgmCompany.addProperty(property);
        properties.add(property); // Keep track of properties

        // Visualize the property in the plot frame
        showPropertyVisual(property);
        showAlert("Property Added: " + propertyName);
    }

    private void showPropertyVisual(Property property) {
        Rectangle house = new Rectangle(property.getPlot().getX(), property.getPlot().getY(),
                                         property.getPlot().getWidth(), property.getPlot().getDepth());
        house.setFill(Color.LIGHTBLUE);
        plotFrame.getChildren().add(house);
    }

    private void displayMaxRent() {
        if (mgmCompany != null) {
            Property highestRentProperty = mgmCompany.getHighestRentPropperty();
            if (highestRentProperty != null) {
                showAlert("Max Rent Property: " + highestRentProperty.getPropertyName() + " with Rent: " + highestRentProperty.getRentAmount());
            } else {
                showAlert("No properties available.");
            }
        }
    }

    private void displayTotalRent() {
        if (mgmCompany != null) {
            double totalRent = mgmCompany.getTotalRent();
            showAlert("Total Rent: " + totalRent);
        }
    }

    private void displayPropertyList() {
        if (mgmCompany != null && !properties.isEmpty()) {
            StringBuilder propertiesList = new StringBuilder("Properties:\n");
            for (Property property : properties) {
                propertiesList.append(property.getPropertyName()).append(", ")
                        .append(property.getCity()).append(", ")
                        .append(property.getRentAmount()).append(", ")
                        .append(property.getOwner()).append("\n");
            }
            showAlert(propertiesList.toString());
        } else {
            showAlert("No properties to display.");
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

