/*
 * Class: CMSC203 
 * Instructor: Dr.Grinberg
 * Description:Tests the ManagementCompany class to confirm that properties can be added, removed, and managed correctly, alongside fee validation.
 * Due: 10/24/24
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. 
 * I have not copied the code from a student or any source. 
 * I have not given my code to any student.
 * Print your Name here: Jedidiah Dawit
*/
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ManagementCompanyTestStudent {
    private ManagementCompany mgmtCompany;
    private Property property1;
    private Property property2;

    @BeforeEach
    public void setUp() {
        mgmtCompany = new ManagementCompany("Test Company", "123-456", 10.0);
        property1 = new Property("Property1", "CityA", 1000.0, "Owner1");
        property2 = new Property("Property2", "CityB", 1500.0, "Owner2");
    }

    @Test
    public void testAddPropertyWithDetails() {
        int index = mgmtCompany.addProperty("Property1", "CityA", 1000.0, "Owner1");
        assertEquals(0, index);
        assertEquals(1, mgmtCompany.getPropertiesCount());
    }

    @Test
    public void testAddPropertyWithCoordinates() {
        int index = mgmtCompany.addProperty("Property2", "CityB", 1500.0, "Owner2", 0, 0, 10, 10);
        assertEquals(0, index); // Ensure it starts at index 0 since it's the first property added
        assertEquals(1, mgmtCompany.getPropertiesCount());
    }

    @Test
    public void testAddPropertyWithExistingObject() {
        int index = mgmtCompany.addProperty(property1);
        assertEquals(0, index);
        assertEquals(1, mgmtCompany.getPropertiesCount());
    }

    @Test
    public void testRemoveLastProperty() {
        mgmtCompany.addProperty(property1);
        mgmtCompany.addProperty(property2);
        mgmtCompany.removeLastProperty();
        assertEquals(1, mgmtCompany.getPropertiesCount());
    }

    @Test
    public void testIsPropertiesFull() {
        for (int i = 0; i < ManagementCompany.MAX_PROPERTY; i++) {
            mgmtCompany.addProperty("Property" + i, "City", 1000.0, "Owner");
        }
        assertTrue(mgmtCompany.isPropertiesFull());
    }

    @Test
    public void testGetPropertiesCount() {
        mgmtCompany.addProperty(property1);
        assertEquals(1, mgmtCompany.getPropertiesCount());
    }

    @Test
    public void testGetHighestRentProperty() {
        mgmtCompany.addProperty(property1);
        mgmtCompany.addProperty(property2);
        Property highest = mgmtCompany.getHighestRentPropperty();
        assertEquals(property2, highest);
    }

    @Test
    public void testIsManagementFeeValid() {
        assertTrue(mgmtCompany.isMangementFeeValid());
    }

    @Test
    public void testGetName() {
        assertEquals("Test Company", mgmtCompany.getName());
    }

    @Test
    public void testGetTaxID() {
        assertEquals("123-456", mgmtCompany.getTaxID());
    }

    @Test
    public void testGetProperties() {
        mgmtCompany.addProperty(property1);
        Property[] properties = mgmtCompany.getProperties();
        assertEquals(property1, properties[0]);
    }

    @Test
    public void testGetMgmFeePer() {
        assertEquals(10.0, mgmtCompany.getMgmFeePer());
    }

    @Test
    public void testGetPlot() {
        Plot plot = mgmtCompany.getPlot();
        assertNotNull(plot);
    }

    @Test
    public void testGetTotalRent() {
        mgmtCompany.addProperty(property1);
        mgmtCompany.addProperty(property2);
        assertEquals(2500.0, mgmtCompany.getTotalRent());
    }

    @Test
    public void testToString() {
        mgmtCompany.addProperty(property1);
        mgmtCompany.addProperty(property2);
        String expected = "Management Company: Test Company, Tax ID: 123-456\n"
                + "Property1,CityA,Owner1,1000.0\n"
                + "Property2,CityB,Owner2,1500.0";
        assertEquals(expected, mgmtCompany.toString().trim());
    }
}
